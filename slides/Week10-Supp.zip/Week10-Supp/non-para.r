# =============================================================== #

# Chi-square #1
male <- c(28, 15, 13)
female <- c(21, 9, 15)
data.chi1 <- rbind(male, female)
colnames(data.chi1) <- c("mw", "cd", "kb")
chisq.test(data.chi1)

# 	    Pearson's Chi-squared test
#
# data:  data.chi1
# X-squared = 1.4622, df = 2, p-value = 0.4814

# =============================================================== #

# Chi-square #2
agree <- c(10, 12, 98)
disagree <- c(30, 48, 102)
data.chi2 <- rbind(agree, disagree)
colnames(data.chi2) <- c("student", "professor", "parent")
chisq.test(data.chi2)

# 	    Pearson's Chi-squared test
#
# data:  data.chi2
# X-squared = 20.5, df = 2, p-value = 3.536e-05

# =============================================================== #

# Mann Whitney U Test
data.mann <- read.csv("nonpara-ex-01.csv", header=T)
wilcox.test(data.mann$result ~ data.mann$machine, exact=F)

# 	Wilcoxon rank sum test with continuity correction
#
# data:  data.mann$result by data.mann$machine
# W = 31, p-value = 0.1526
# alternative hypothesis: true location shift is not equal to 0

# =============================================================== #

# Wilcoxon Signed-Rank Test
data.wilcox <- read.csv("nonpara-ex-02.csv", header=T)
test <- wilcox.test(data.wilcox$score.a, data.wilcox$score.b, mu=0, alt="two.sided", paired=T, exact=F, correct=F)
z <- qnorm(test$p.value/2)
r <- z/sqrt(10) # N = 10 in this case
print(test)
print(z)
print(r)

# 	Wilcoxon signed rank test
#
# data:  data.wilcox$score.a and data.wilcox$score.b
# V = 34, p-value = 0.02418
# alternative hypothesis: true location shift is not equal to 0

# =============================================================== #

# Kruskal-Wallis Test
data.kru <- read.csv("nonpara-ex-03.csv", header=T)
kruskal.test(score ~ group, data = data.kru)

# 	Kruskal-Wallis rank sum test
#
# data:  score by group
# Kruskal-Wallis chi-squared = 9.605, df = 2, p-value = 0.008209

# =============================================================== #

# Friedman Test
data.fr <- read.csv("nonpara-ex-04.csv", header=T)
friedman.test(result ~ interface|participant, data.fr)

# 	Friedman rank sum test
#
# data:  result and interface and participant
# Friedman chi-squared = 8.6923, df = 3, p-value = 0.03367

# =============================================================== #
