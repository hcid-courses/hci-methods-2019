# =============================================================== #

data1 <- read.csv("anova-ex-01.csv", header=T)
data1.fit <- aov(rt~method+Error(participant/method), data=data1)
summary(data1.fit)

# Error: participant
#           Df Sum Sq Mean Sq F value Pr(>F)
# Residuals  9  4.884  0.5427
#
# Error: participant:method
#           Df Sum Sq Mean Sq F value Pr(>F)
# method     1  4.141   4.141   9.593 0.0128 *
# Residuals  9  3.884   0.432

# =============================================================== #

data2 <- read.csv("anova-ex-02.csv", header=T)
data2.fit <- aov(rt~method+Error(participant/method), data=data2)
summary(data2.fit)

# Error: participant
#           Df Sum Sq Mean Sq F value Pr(>F)
# Residuals  9  37.37   4.152
#
# Error: participant:method
#           Df Sum Sq Mean Sq F value Pr(>F)
# method     1   4.32   4.325   0.626  0.449
# Residuals  9  62.14   6.904

# =============================================================== #

data3 <- read.csv("anova-ex-03.csv", header=T)
data3.fit <- aov(unit~method+Error(participant/method), data3)
summary(data3.fit)

# Error: participant
#           Df Sum Sq Mean Sq F value Pr(>F)
# Residuals 15  81.11   5.407
#
# Error: participant:method
#           Df Sum Sq Mean Sq F value  Pr(>F)
# method     3  182.2   60.72   4.954 0.00468 **
# Residuals 45  551.6   12.26

# =============================================================== #

require(nlme)
data3.fit.lme <- lme(unit ~ method, data=data3, random = ~1|participant)
anova(data3.fit.lme)
require(multcomp)
summary(glht(data3.fit.lme,linfct=mcp(method="Tukey")))

# Linear Hypotheses:
#            Estimate Std. Error z value Pr(>|z|)
# B - A == 0   0.8750     1.1481   0.762  0.87147
# C - A == 0   4.5000     1.1481   3.920  < 0.001 ***
# D - A == 0   1.8125     1.1481   1.579  0.39084
# C - B == 0   3.6250     1.1481   3.157  0.00852 **
# D - B == 0   0.9375     1.1481   0.817  0.84668
# D - C == 0  -2.6875     1.1481  -2.341  0.08890 .
# ---
# Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# (Adjusted p values reported -- single-step method)

# =============================================================== #

data4 <- read.csv("anova-ex-04.csv", header=T)
data4.fit <- aov(comp ~ handedness, data4)
summary(data4.fit)

#             Df Sum Sq Mean Sq F value Pr(>F)
# handedness   1  18.06  18.063   3.781 0.0722 .
# Residuals   14  66.88   4.777
# ---
# Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1

# =============================================================== #

data5 <- read.csv("anova-ex-05.csv", header=T)
data5$device <- as.factor(data5$device)
data5$task <- as.factor(data5$task)
data5.fit <- aov(comp ~ device * task + Error(participant/(device * task)), data5)
summary(data5.fit)

# Error: participant
#           Df Sum Sq Mean Sq F value Pr(>F)
# Residuals 11  134.8   12.25
#
# Error: participant:device
#           Df Sum Sq Mean Sq F value  Pr(>F)
# device     2    121   60.51   5.865 0.00909 **
# Residuals 22    227   10.32
# ---
# Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
#
# Error: participant:task
#           Df Sum Sq Mean Sq F value Pr(>F)
# task       1   0.89   0.889   0.076  0.787
# Residuals 11 128.11  11.646
#
# Error: participant:device:task
#             Df Sum Sq Mean Sq F value Pr(>F)
# device:task  2    121   60.51   5.435 0.0121 *
# Residuals   22    245   11.14
# ---
# Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1

# =============================================================== #
